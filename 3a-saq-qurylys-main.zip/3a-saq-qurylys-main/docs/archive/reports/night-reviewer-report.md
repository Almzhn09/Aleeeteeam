# Проверка готовности к демонстрации и сдаче

База: `fix/security-demo-hardening`, полный SHA
`d5795669fd567d8da4a2fc473f30ec0f3296b4d3`.
Рабочая ветка: `test/night-release-readiness`. Начало: 15 октября 2026,
23:16 Asia/Almaty (18:16 UTC); предел активной работы — пять часов.
Это проверка локальной Linux-среды; результаты не означают публикацию в Hosting
или Cloud Run. Живые данные/инфраструктура и платный Gemini не используются.

## База и координация

Прочитаны AGENTS, PROJECT_SPEC, DEVELOPMENT_PLAN, WORK_LOG и три night-отчёта.
Получены все удалённые heads. Указанная база включает backend/frontend/security
исправления; уже выполненные функции заново не реализуются. Исходное рабочее
дерево чистое, прежней несохранённой работы нет. Исторические PR: #1 backend,
#2 frontend, #3 security. GitHub GraphQL и REST PR/check-runs вернули `Forbidden`
в текущей сессии; состояние PR/CI по этим ответам установить нельзя. Git read
работает, ветка будет отправляться по этапам; доступ к API проверяется повторно
перед завершением. `main` не меняется.

## Этап 1 — чистая установка

Создан Git-export точного HEAD в `/tmp/saq-release-clean`, только tracked-файлы:
без `.env`, production env, `node_modules`, `.venv` и credentials. Это чистая копия
на этой же Linux-машине, не второй Windows-компьютер.

| Проверка | Фактический результат |
| --- | --- |
| Node / npm / uv / Python | 24.19.0 / 11.9.0 / 0.12.23 / 3.12.14 |
| `frontend`: `npm ci` | Установлены 265 пакетов из package-lock.json |
| `npm test` | 48 passed, 12 test files |
| `npm run typecheck`, `npm run build` | Успешно |
| `backend`: `uv sync --frozen` | 63 пакета из uv.lock, отдельная новая .venv |
| `uv run --frozen pytest -q` | 218 passed; один прежний StarletteDeprecationWarning |
| Ruff check / format | Успешно, 66 файлов |
| `python -m app.cli.seed validate` | 8 застройщиков, 8 ЖК, 12 объявлений, 9 источников |
| `python -m app.cli.check` без конфигурации | Exit 1: Firebase/Storage FAILED, Gemini SKIPPED; ожидаемая диагностика, не успешное подключение |

Оба Docker-образа собраны из чистого export с frozen lockfiles. Для сетевого
ограничения этой машины потребовались штатные proxy build args, host build network,
`--add-host` для имени прокси по текущему `/etc/hosts` и поддерживаемый secret
`custom_ca`. Проверка TLS/подписей не отключалась, Dockerfiles не менялись.
Первый build остановлен после `Temporary failure resolving 'proxy'`; это свойство
build sandbox, а не ошибка приложения. `docker compose -p saq-release-clean up
--no-build --wait --wait-timeout 120` успешно запустил оба образа: оба healthy.
Health напрямую на 8000 и через frontend proxy на 5173 вернул точный JSON;
защищённый каталог без токена — 401. Chromium по прямому URL карточки без
конфигурации показал «Подключите рабочую среду», без рабочей навигации.

README уточнён: просмотр опубликованного сайта отдельно от локального запуска,
фактические проверки владельца отдельно от PR; добавлены системные PDF-зависимости
для Linux и создание `.env` без перезаписи существующего файла.

## Воспроизведения перед исправлением frontend

- **AUTH-01:** войти с принятым токеном → API следующего раздела отвечает 401.
  На базе навигация и рабочая оболочка остаются; меняется только ошибка запроса.
  Если `getIdToken()` отклонён с `auth/user-token-expired`, интерфейс также остаётся
  открытым и показывает исходный текст SDK exception. Два новых regression-теста
  воспроизвели дефект (2 failed), контрольный offline-тест прошёл.
- **NAV-01:** в реестре задать поиск/город/приоритет → открыть карточку → browser
  Back. На базе фильтры сбрасывались, так же при reload. Regression-тест упал
  на пустом поле поиска после возврата. Теперь применённые параметры и курсор
  хранятся в URL, browser Back/Forward/reload восстанавливают выборку.
- **SIGNAL-01:** открыть создание сигнала, заполнить заголовок/основание → другой
  аналитик меняет версию ЖК → создать. Ответ 409 сохранял поля, но повтор всегда
  посылал прежнюю версию; полный reload терял ввод. Regression-тест сначала упал
  из-за отсутствия безопасного обновления. Теперь есть «Обновить данные ЖК»:
  GET новой версии, сохранение обоих полей, явная повторная проверка и отправка.

## Этап 2 — браузер и исправления

Добавлен opt-in runner `frontend/qa/release/run.py` на уже доступном Playwright
1.62.0 + системном Chromium, без новой frontend/backend зависимости. Production
entry/config не импортируют adapters; QA Vite config включает явную плашку.
Реальные API routes/services, validation, risk и WeasyPrint работают с существующими
MemoryStore/FakeFiles/Gemini MockTransport. Browser Auth adapter заменяет только
внешний SDK; проверяется настоящий AuthProvider. Все процессы только loopback;
application credentials/env исключаются, внешние browser requests запрещены.

Завершённый прогон: **14 контрольных групп passed**, 432 browser requests, 0 page
errors, 0 внешних запросов. Артефакты этого прогона:
`/tmp/saq-release-browser-complete/results.json`, локальный настоящий PDF и снимок
мобильного экрана. Runner останавливает свои процессы и начинает с нового seed.

| Область | Проверено фактически |
| --- | --- |
| Авторизация | Прямая protected ссылка без входа; ошибка входа/очистка пароля; вход/выход/reload; ранее принятый токен → 401 → закрытие workspace → повторный вход |
| Каталог | Поиск/город/зона, пустая выборка, карточка/Back/Forward/reload, сохранение URL/cursor; реальная пагинация с уменьшенным limit |
| Объявление | Native required validation не отправляет POST; ошибка сохранения и явный повтор; исходные пробелы/переносы сохранены backend без изменений |
| AI | Pending/disabled состояние, реальный service с MockTransport, гипотеза, отсутствие гипотез на безобидном тексте, model/quota/network errors |
| Файл | Неверный MIME и повреждённый PNG отвергнуты реальным валидатором; >6 MiB не отправляется; допустимый PNG сохраняется и открывается через закрытый API |
| Разделение решений | Принятие AI = 10; source review = 10; отдельное решение R2 = 35, score получен с backend |
| Сигнал | UI draft → submit → return → resubmit → confirm; реальное конкурирующее решение даёт 409; комментарий сохраняется при GET refresh |
| Новый сигнал | Реальный конфликт версии ЖК; GET refresh, сохранённые title/reason, явное повторное создание |
| История | Loading, настоящие страницы audit с limit=2, typed index error/retry; пустая история — явно введённый fixture |
| PDF | HTML 200 не скачан; ошибка рендера показана; retry скачал настоящий локальный WeasyPrint `%PDF-` |
| Ссылки/адаптивность | Точный href/rel источника, deep link evidence; 1366×768, 375×812, 320×700 без page overflow; keyboard skip link |

AUTH-01 исправлен в AuthProvider: 401 и известные SDK-коды недействительной
сессии убирают profile/workspace, SDK-текст не показывается. Network/refresh outage
показывает безопасную ошибку с возможностью retry и не разлогинивает. Revision
защищает новый вход от позднего 401 старой сессии. Тестовые SDK/HTTP не подменяют
backend-проверку Firebase token или правила доступа в реальной среде.

После этих исправлений: **55 frontend tests passed**, 14 test files; отдельный
TypeScript check и production build успешны. QA adapters не найдены в собранном
`frontend/dist` по их уникальным маркерам. Lockfiles и зависимости не изменены.

Первые browser-прогоны остановились из-за двух ошибок самого нового runner:
он пытался декодировать бинарный upload как текст и выбирал все два источника
вместо нужного checkbox. Исправлены только runner/selector; после этого полный
прогон выше завершён с exit 0. Это не дефекты продукта и не cloud failures.

Read-only HTTPS-проверка Hosting/Cloud Run из этой машины остановилась до сервисов:
egress proxy вернул `Tunnel connection failed: 403 Forbidden`. Это не ответ
приложения и не подтверждение его недоступности. Живой вход/версию, PDF, историю
и screenshot по-прежнему проверяет владелец после публикации.

## Этап 3 — сочетания конфликтов и regression-тесты

- **REVIEW-01 (три редактора):** открыть проверку источника / фактора / основания,
  ввести решение, другим запросом изменить соответствующую версию, сохранить.
  409 показывался, но редакторы не умели обновить версию без потери ввода.
  Три regression-теста сначала упали из-за отсутствия read-only refresh. Добавлен
  общий `useReviewRecord`: форма остаётся смонтированной, свежая версия/серверные
  сведения видимы, текст/checkbox сохранены, повторная отправка только явно.
  При ошибке GET кнопка обновления остаётся доступной, запись заблокирована,
  черновик сохранён. Источник, уже связанный с подтверждённым фактором, по-прежнему
  нельзя менять без пересмотра фактора; backend остаётся решающим.
- **AI-REVIEW-01:** набрать обоснование/выбрать отклонение гипотезы → 409 →
  «Обновить результаты». На базе textarea сбрасывалась при загрузке списка.
  Тест воспроизвёл пустое поле. Теперь поля управляются состоянием панели.
  Если другой аналитик уже рассмотрел гипотезу, несохранённый текст виден отдельно,
  повторное решение не отправляется. Backend не менялся.
- **PDF-01:** вернуть HTML с ошибочно указанным `application/pdf`. Старый MIME
  guard разрешал скачивание под `.pdf`; новый тест воспроизвёл отсутствие ошибки
  и создание download URL. Теперь до Blob URL проверяются MIME и первые пять
  байтов `%PDF-`; HTML/пустой/не-PDF ответ не скачивается. Это проверка сигнатуры,
  не полноценный валидатор всех PDF-объектов.

Расширенный Chromium с реальными локальными конкурентными API-записями прошёл:
15 групп / 497 browser requests, 0 page errors / внешних запросов. Дополнительно
пройдены source deep link + reload + фокус, конфликты AI/source/factor/basis при
375px и keyboard refresh. Артефакты:
`/tmp/saq-release-browser-conflicts-2/`. `pdftotext` подтвердил DEMO, 35, исходную
цитату 135 000, `qa-local-analyst` и заголовок в настоящем локальном PDF.
После дополнительного PDF guard проводится финальный прогон ниже.

После PDF guard: **61 frontend tests passed**, 15 test files; typecheck и build
успешны. Есть предупреждение Vite о main chunk ~501 kB (gzip ~154 kB), без
подавления порога и без несвязанного рефакторинга. Chromium с обоими HTML MIME
сценариями: **15 групп passed / 499 requests**, нет page errors/внешних запросов,
артефакты `/tmp/saq-release-browser-final/`. QA runner дополнительно изолирует cwd
API в пустой временной папке, чтобы даже модульный default app не читал `.env`
из рабочего checkout. Этот startup также прошёл: 15 групп / 499 запросов,
`/tmp/saq-release-browser-isolated-final/`, exit 0, процессы runner завершены.

Новых подтверждённых backend-дефектов в этом проходе не найдено. Общий код
`CONFLICT` покрывает несколько причин: например, открыть source review, другим
запросом подтвердить связанный фактор, затем сохранить прежний source review —
backend корректно отклоняет действие, но не отдаёт отдельный typed code для
блокировки источника. UI даёт фиксированную подсказку проверить факторы. Код/
контракт не менялись. Причина прежней облачной ошибки истории здесь не установлена.

## Этап 4 — пакет организатора

- README: отдельные инструкции просмотра сайта и локального запуска, новая копия
  правильной ветки/SHA, lockfiles, Linux PDF system dependencies, безопасное
  создание `.env`, точные рабочие папки, ожидаемый health/setup screen.
- Windows: PowerShell-команды clone/start/health/stop, без перезаписи `.env`;
  административные seed/claims отделены от обычного запуска. Windows не запускался.
- Firebase setup: четыре обязательных browser-поля, backend/private credentials
  отдельно, host/container пути, online-check без генерации; существующая Cloud Run
  модель отмечена как выбор владельца, не доказательство доступа в другом проекте.
- Demo scenarios: актуальные названия кнопок и полный цикл сигнала; исходные
  баллы seed не выдаются за неизменяемое состояние shared DEMO.
- `judge-runbook.md`: показ примерно на 6:30, честный ручной резерв при отказе
  Gemini, отдельный резерв при отказе Firebase/API, список ручной облачной приёмки
  и сдачи конкретного SHA после review/CI.

Проверены локальные Markdown targets: отсутствующих нет. Изменений вне
разрешённых frontend/docs/README нет. Backend/deploy/rules/индексы/Compose/API
schemas/R1–R6/dependencies/lockfiles идентичны базе; только frontend использует
новые regression-тесты и обработку восстановления.

## Финальная проверка и внешние ограничения

После последнего code-коммита `495a4c9` создан второй чистый Git-export
`/tmp/saq-release-final` без секретов/готовых зависимостей. Повторный frontend
`npm ci`, **61 tests**, typecheck и build прошли. Backend остался побайтово
неизменённым относительно базы, для которой выполнены **218 tests + Ruff**;
не объявляется новым независимым backend-прогоном на каждом docs-коммите.
Финальный frontend Docker build успешен (image
`sha256:4f2e130886628b2db9caba5e050dca6157caef28cca4103afbbc194740414db7`).
Backend image переиспользован, так как backend не изменён. Compose пересоздал
frontend; оба контейнера healthy. Health на 8000 и через proxy на 5173 — точный
ожидаемый JSON; `/api/v1/signals` без token — 401. Chromium по прямому protected
URL показывает configuration notice, без navigation/QA banner. Проверено
отсутствие QA-маркеров в чистом production bundle.

Коммиты отправлялись по этапам: `253a8e9` (чистая установка/инструкции),
`79a9229` (auth/catalog/signal и browser runner), `495a4c9` (остальные conflicts,
AI draft и PDF header). Следующий docs-коммит завершает пакет организатора;
его точный SHA доступен через `git rev-parse HEAD`/историю ветки.

Не выполнены и не считаются пройденными: реальный Firebase login/token/rules/IAM,
облачные история/индексы/PDF/screenshot, платные RU/KZ/image генерации,
Windows/второе устройство, независимый reviewer и CI. Владельцу — конкретная
матрица в конце judge-runbook. Сохранённые инструкции не публикуют сайт и не
меняют Cloud Run модель, данные или инфраструктуру.

## Передача PR и CI

Ветка `test/night-release-readiness` отправлена в origin по всем этапам. Git refs
подтвердили существующие PR heads #1 = ac11efc, #2 = 94cda6b, #3 = d579566;
security-база в origin осталась d579566. Их состояние review/merge нельзя вывести
из Git refs, а PR API в этой сессии недоступен.

После push пакета `9519958` выполнена команда:

```bash
gh pr create --repo arturk0-0/3a-saq-qurylys \
  --base fix/security-demo-hardening --head test/night-release-readiness \
  --title "fix(release): preserve review drafts and validate demo readiness" \
  --body-file /tmp/saq-release-pr.md
```

Подготовлено полное описание, но создание остановлено до результата:
`Post https://api.github.com/graphql: Forbidden`. REST `/commits/9519958/check-runs`
и `/commits/9519958/status` также вернули `Forbidden`. **PR не создан, CI не
подтверждён**. Это ограничение доступа к GitHub API, не упавшие application tests.
Для последнего report-only коммита доступ к CI проверяется повторно; результат
при прежнем отказе не будет объявлен зелёным.

[Создать PR с нужной базой](https://github.com/arturk0-0/3a-saq-qurylys/compare/fix/security-demo-hardening...test/night-release-readiness?expand=1).
Заголовок указан выше. Для body: перечислить AUTH-01/NAV-01/SIGNAL-01/REVIEW-01/
AI-REVIEW-01/PDF-01, проверки 218 backend / 61 frontend / 15 Chromium groups,
ссылки на этот отчёт и judge-runbook, ограничения live/Windows/CI. Полный готовый
body также сохранён локально в `/tmp/saq-release-pr.md`.

Владелец открывает PR именно в `fix/security-demo-hardening`, проверяет Checks
**финального SHA** на GitHub и получает независимое review. После согласованной
публикации проходит ручную матрицу judge-runbook, прежде всего облачные историю,
PDF и screenshot. Автоматического merge, deploy или изменения живых данных нет.
