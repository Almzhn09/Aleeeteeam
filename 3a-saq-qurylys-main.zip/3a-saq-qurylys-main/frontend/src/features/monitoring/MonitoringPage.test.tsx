import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { expect, it, vi } from 'vitest'
import { AuthContext } from '@/features/auth/AuthProvider'
import { ApiError, type ApiClient } from '@/lib/http'
import { MonitoringPage } from './MonitoringPage'
import { FindingDetail } from './FindingDetail'
import { SourceManager } from './SourceManager'
import type { Finding } from './types'

const item: Finding = {
  id: 'lead1', title: 'Synthetic QA lead', text: 'DEMO Өскемен, квартиры. Депозит. <img src=x onerror=alert(1)>',
  originalUrl: 'https://example.org/qa-ad', discoveryUrl: 'https://www.bing.com/search?q=qa',
  contentKind: 'search_snippet', account: 'example.org', publishedAt: null,
  createdAt: '2026-10-17T10:00:00Z', lastSeenAt: '2026-10-17T10:00:00Z',
  regionMatches: ['өскемен'], housingMatches: ['квартир'], paymentMatches: ['депозит'],
  textSha256: 'a'.repeat(64), responseSha256: 'b'.repeat(64), revisionKey: 'c'.repeat(64),
  sourceIds: ['s1'], status: 'new', notes: '', reviewer: null, reviewedAt: null,
  version: 1, aiStatus: 'not_requested', aiError: null, aiModel: null,
  extraction: null, advertisementId: null,
}
function setup(node: React.ReactNode, api: ApiClient, entries = ['/monitoring']) {
  return render(<AuthContext.Provider value={{ status: 'authenticated', profile: null,
    error: null, api, signIn: vi.fn(), logout: vi.fn() }}>
    <MemoryRouter initialEntries={entries}>{node}</MemoryRouter>
  </AuthContext.Provider>)
}
it('distinguishes Instagram target unavailability and search snippets without starting collection or AI', async () => {
  const api = vi.fn(async (path: string, _init?: RequestInit) => {
    if (path.endsWith('/status')) return { workerLastTickAt: null, dailyFetchUsed: 0,
      dailyFetchLimit: 100, maxAutoAiPerRun: 1, liveRegistryEnabled: false, instagramTargetedAds: 'not_connected' }
    if (path.endsWith('/sources')) return { items: [] }
    if (path.endsWith('/items/lead1')) return item
    if (path.includes('/history')) return { items: [], nextCursor: null }
    return { items: [item], nextCursor: null }
  })
  const result = setup(<MonitoringPage />, api as ApiClient)
  expect(await screen.findByText('Synthetic QA lead')).toBeInTheDocument()
  expect(screen.queryByRole('heading', { name: 'Автосбор таргетированной рекламы KZ пока не подключён' })).not.toBeInTheDocument()
  expect(screen.getByText('Фрагмент поиска')).toBeInTheDocument()
  expect(screen.getByText(/Источники можно запустить вручную/)).toBeInTheDocument()
  expect(result.container.querySelector('img')).toBeNull()
  expect(api.mock.calls.every(([, init]) => !init?.method)).toBe(true)
  fireEvent.click(screen.getByRole('button', { name: 'Рассмотреть находку' }))
  expect(await screen.findByRole('heading', { name: 'Проверка находки' })).toBeInTheDocument()
})
it('source creation needs explicit opt-in for paid automatic AI', async () => {
  const api = vi.fn(async () => ({ id: 's1' }))
  setup(<SourceManager sources={[]} changed={vi.fn()} />, api as ApiClient)
  const checkbox = screen.getByRole('checkbox')
  expect(checkbox).not.toBeChecked()
  fireEvent.click(screen.getByRole('button', { name: 'Сохранить источник' }))
  await screen.findByText(/Источник сохранён/)
  const first = JSON.parse(String((api.mock.calls as unknown as [string, RequestInit][])[0][1].body))
  expect(first).toMatchObject({ kind: 'web_search', autoAnalyze: false, intervalMinutes: 60 })
  fireEvent.click(checkbox)
  fireEvent.click(screen.getByRole('button', { name: 'Сохранить источник' }))
  await waitFor(() => expect(api).toHaveBeenCalledTimes(2))
  const second = JSON.parse(String((api.mock.calls as unknown as [string, RequestInit][])[1][1].body))
  expect(second.autoAnalyze).toBe(true)
})
it('expert conflict keeps notes across refresh and retries with the new version without writing a factor', async () => {
  let current = { ...item }
  const api = vi.fn(async (path: string, init?: RequestInit) => {
    if (path.includes('/history')) return { items: [], nextCursor: null }
    if (!init?.method) return current
    if (path.endsWith('/review')) {
      const body = JSON.parse(String(init.body))
      if (body.expectedVersion === 1) {
        current = { ...current, version: 2 }
        throw new ApiError(409, 'CONFLICT', 'Данные изменились')
      }
      current = { ...current, version: 3, status: body.decision, notes: body.notes }
      return current
    }
    throw new Error('Unexpected mutation: ' + path)
  })
  setup(<FindingDetail id="lead1" liveRegistry={false} changed={vi.fn()} />, api as ApiClient)
  const notes = await screen.findByLabelText('Обоснование решения')
  fireEvent.change(notes, { target: { value: 'QA: сверить исходный пост' } })
  fireEvent.click(screen.getByRole('button', { name: 'Сохранить решение эксперта' }))
  await screen.findByText('Данные изменились')
  fireEvent.click(screen.getByRole('button', { name: 'Обновить материал' }))
  expect(await screen.findByLabelText('Обоснование решения')).toHaveValue('QA: сверить исходный пост')
  fireEvent.click(screen.getByRole('button', { name: 'Сохранить решение эксперта' }))
  await screen.findByText(/Решение по находке сохранено/)
  const writes = api.mock.calls.filter(([, init]) => init?.method)
  expect(writes).toHaveLength(2)
  expect(writes.every(([path]) => path.endsWith('/review'))).toBe(true)
  expect(JSON.parse(String(writes[1][1]?.body))).toMatchObject({ expectedVersion: 2, notes: 'QA: сверить исходный пост' })
})
it('does not offer attaching real findings to the DEMO registry or invent a publication date', async () => {
  const api = vi.fn(async (path: string) => path.includes('/history') ? { items: [], nextCursor: null } : item)
  setup(<FindingDetail id="lead1" liveRegistry={false} changed={vi.fn()} />, api as ApiClient)
  expect(await screen.findByText(/Для продолжения нужна карточка реального ЖК/)).toBeInTheDocument()
  expect(screen.getByText(/Опубликовано: Не указано/)).toBeInTheDocument()
  expect(screen.queryByLabelText('Реальный жилой комплекс')).not.toBeInTheDocument()
  expect(screen.queryByRole('button', { name: 'Проанализировать с AI' })).not.toBeInTheDocument()
})

it('creates an Instagram Ad Library source with a single-city query and no automatic AI', async () => {
  const api = vi.fn(async () => ({ id: 'meta-source' }))
  setup(<SourceManager sources={[]} changed={vi.fn()} />, api as ApiClient)
  fireEvent.change(screen.getByLabelText('Тип источника'), { target: { value: 'instagram_ads' } })
  expect(screen.getByLabelText('Поисковый запрос')).toHaveValue('квартиры Өскемен')
  expect(screen.getByText(/Поиск активной рекламы Instagram по Казахстану/)).toBeInTheDocument()
  expect(api).not.toHaveBeenCalled()
  fireEvent.click(screen.getByRole('button', { name: 'Сохранить источник' }))
  await screen.findByText(/Источник сохранён/)
  const writes = api.mock.calls as unknown as [string, RequestInit][]
  expect(JSON.parse(String(writes[0][1].body))).toMatchObject({
    kind: 'instagram_ads', target: 'квартиры Өскемен', autoAnalyze: false,
  })
})
it('shows Meta campaign date separately and never auto-loads external creative files', async () => {
  const meta: Finding = { ...item, contentKind: 'instagram_ad', adArchiveId: '100000000000001',
    adStartedAt: '2026-10-15T07:00:00Z', adActive: true, platforms: ['INSTAGRAM'],
    media: [{ kind: 'video', url: 'https://cdn.example.org/demo.mp4' }] }
  const api = vi.fn(async (path: string) => path.includes('/history') ? { items: [], nextCursor: null } : meta)
  const result = setup(<FindingDetail id="lead1" liveRegistry={false} changed={vi.fn()} />, api as ApiClient)
  expect(await screen.findByText(/ID 100000000000001/)).toBeInTheDocument()
  expect(screen.getByText(/Это не дата публикации исходного поста/)).toBeInTheDocument()
  expect(screen.getByText(/Опубликовано: Не указано/)).toBeInTheDocument()
  expect(result.container.querySelectorAll('img,video,iframe')).toHaveLength(0)
  expect(result.container.querySelector('a[href="https://cdn.example.org/demo.mp4"]')).toHaveAttribute('rel', 'noopener noreferrer')
  expect(api.mock.calls.every(([path]) => String(path).startsWith('/api/v1/'))).toBe(true)
})
it('reports configured Instagram and reserved quota without launching a provider search', async () => {
  const api = vi.fn(async (path: string, _init?: RequestInit) => {
    if (path.endsWith('/status')) return { instagramTargetedAds: 'configured', workerLastTickAt: null,
      dailyFetchUsed: 0, dailyFetchLimit: 100, searchApi: { scheduled: false, dailyLimit: 2,
        dailyUsed: 0, creditReserve: 20, creditsObservedBefore: 99, checkedAt: item.createdAt, unsettledAttempts: 0 } }
    return { items: [], nextCursor: null }
  })
  setup(<MonitoringPage />, api as ApiClient)
  await screen.findByText(/Источники можно запустить вручную/)
  expect(screen.queryByRole('heading', { name: 'Источник Instagram настроен через SearchAPI' })).not.toBeInTheDocument()
  expect(screen.queryByText(/Берегём квоту/)).not.toBeInTheDocument()
  fireEvent.click(screen.getByRole('button', { name: 'Источники сбора' }))
  const settings = screen.getByText('Подключения и лимиты')
  expect(settings.parentElement).not.toHaveAttribute('open')
  fireEvent.click(settings)
  expect(await screen.findByRole('heading', { name: 'Источник Instagram настроен через SearchAPI' })).toBeVisible()
  expect(screen.getByText(/Берегём квоту: резерв 20 запросов/)).toBeInTheDocument()
  expect(screen.getByText(/Это не текущий баланс/)).toBeInTheDocument()
  expect(api.mock.calls.every(([, init]) => !init?.method)).toBe(true)
})

it('hides reviewer identifiers in the saved decision and audit while keeping timestamps and notes', async () => {
  const reviewed = { ...item, reviewer: 'private-reviewer-uid', reviewedAt: item.createdAt,
    notes: 'Проверить документы', status: 'investigating' }
  const api = vi.fn(async (path: string) => path.includes('/history')
    ? { items: [{ id: 'event1', actorUid: 'private-reviewer-uid', action: 'item.review',
      createdAt: item.createdAt, details: { notes: 'Проверить документы' } }], nextCursor: null }
    : reviewed)
  const result = setup(<FindingDetail id="lead1" liveRegistry={false} changed={vi.fn()} />, api as ApiClient)
  await screen.findByText(/Решение: В работе эксперта/)
  fireEvent.click(screen.getByText('История решений по находке'))
  await waitFor(() => expect(result.container.textContent?.match(/Аналитик/g)).toHaveLength(2))
  expect(result.container.innerHTML).not.toContain('private-reviewer-uid')
  expect(result.container.textContent).not.toContain('[object Object]')
  expect(screen.queryByText(/платный запрос/)).not.toBeInTheDocument()
  expect(api.mock.calls.every(([path]) => String(path).startsWith('/api/v1/'))).toBe(true)
})
